import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  formulario:FormGroup;
  fecha:Date;
  publicaciones:any[];
    constructor() {
      this.publicaciones = [];
      this.formulario = new FormGroup({
        'nombre': new FormControl('', [Validators.required,Validators.minLength(5)]),
        'entrada': new FormControl('', [Validators.required,Validators.minLength(30)]),

      })
    }

  ngOnInit() {
  }

  guardar(){
    console.log(this.formulario.value);
    let newPublicacion = {} as Publicacion;
    newPublicacion.entrada = this.formulario.value.entrada;
    newPublicacion.nombre = this.formulario.value.nombre;
    newPublicacion.fecha = new Date();
    this.publicaciones.push(newPublicacion);
  }



}

export interface Publicacion{
  nombre:string;
  entrada:string;
  fecha:Date;
}
